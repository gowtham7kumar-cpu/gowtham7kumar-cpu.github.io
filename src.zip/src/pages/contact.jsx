import CloudSection from "../components/CloudSection";

export default function Contact() {
  return (
    <main className="bg-white text-black font-poppins overflow-x-hidden">
      <CloudSection>
        <section className="min-h-[70vh] flex flex-col justify-center items-center text-center px-6">
          <h1 className="text-5xl md:text-6xl font-light uppercase">
            Contact
          </h1>
          <div className="h-[3px] w-16 mt-5 bg-[#d7263d]" />
          <p className="mt-6 max-w-xl text-neutral-600 text-lg">
            Ready to collaborate? Let’s build something exceptional together.
          </p>

          <div className="mt-10">
            <a
              href="mailto:hello@evokefilms.com"
              className="px-8 py-3 rounded-full bg-[#d7263d] text-white hover:opacity-90 transition"
            >
              hello@evokefilms.com
            </a>
          </div>
        </section>
      </CloudSection>
    </main>
  );
}
