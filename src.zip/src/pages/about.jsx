import CloudSection from "../components/CloudSection";

export default function About() {
  return (
    <main className="bg-white text-black font-poppins overflow-x-hidden">
      <CloudSection>
        <section className="min-h-[70vh] flex flex-col justify-center items-center text-center px-6">
          <h1 className="text-5xl md:text-6xl font-light uppercase">
            About Us
          </h1>
          <div className="h-[3px] w-16 mt-5 bg-[#d7263d]" />
          <p className="mt-6 max-w-2xl text-neutral-600 text-lg leading-relaxed">
            Evoke Films is a creative agency specializing in cinematic storytelling, design-driven branding, and motion production.  
            Our philosophy: connect, create, collaborate.
          </p>
        </section>
      </CloudSection>

      <CloudSection>
        <section className="max-w-4xl mx-auto px-6 py-20 text-center">
          <p className="text-neutral-500 leading-relaxed">
            From commercial shoots to full creative campaigns, we handle everything end-to-end — concept, production, post, and rollout.  
            We believe visuals should evoke emotion and drive impact.
          </p>
        </section>
      </CloudSection>
    </main>
  );
}
